### Name: GeneProduct-class
### Title: Class "GeneProduct"
### Aliases: GeneProduct-class GeneProduct getIds setIds getSystems
###   setSystems getIds,GeneProduct-method setIds,GeneProduct-method
###   getSystems,GeneProduct-method setSystems,GeneProduct-method
###   print,GeneProduct-method ==,GeneProduct-method
###   as.matrix,GeneProduct-method
### Keywords: classes

### ** Examples

    gp1 = GeneProduct(ids = c("1234", "2345"), systems = c("L", "L"))
    gp2 = GeneProduct(ids = c("9876", "1234"), systems = c("L", "L"))
    gp1 == gp2
    print(gp1)



