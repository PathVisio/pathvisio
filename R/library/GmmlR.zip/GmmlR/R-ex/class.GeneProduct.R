### Name: GeneProduct-class
### Title: Class "GeneProduct"
### Aliases: GeneProduct-class class:GeneProduct GeneProduct
###   name,GeneProduct-method name<-,GeneProduct-method
###   addReference<-,GeneProduct-method ==,GeneProduct-method
### Keywords: methods classes

### ** Examples

    gp1 = GeneProduct(cbind(c("1234", "2345"), c("L", "L")))
    gp2 = GeneProduct(cbind(c("9876", "1234"), c("U", "L")))
    gp1 == gp2
    gp1 == "L:2345"
    gp1[,'id']
    gp1[,'code']
    addReference(gp1) = c("1234_at","X")
    addReference(gp1) = "En:ENSG0001"




